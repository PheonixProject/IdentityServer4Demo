﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;
using ImageGallery.Client.Services;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Linq;
using Microsoft.AspNetCore.Authentication;
using System.IdentityModel.Tokens.Jwt;

namespace ImageGallery.Client
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();

            // Custom authorisation policy! Based on claims the user has!!
            services.AddAuthorization(authorizationOptions =>
            {
                authorizationOptions.AddPolicy(
                    "CanSeeAddress",
                    policyBuilder =>
                    {
                        policyBuilder.RequireAuthenticatedUser();
                        policyBuilder.RequireClaim("country", "uk");
                        policyBuilder.RequireClaim("subscriptionLevel", "Admin");

                    });
            });

            // register an IHttpContextAccessor so we can access the current
            // HttpContext in services by injecting it
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            // register an IImageGalleryHttpClient
            services.AddScoped<IImageGalleryHttpClient, ImageGalleryHttpClient>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseBrowserLink();
            }
            else
            {
                app.UseExceptionHandler("/Shared/Error");
            }

            app.UseCookieAuthentication(new CookieAuthenticationOptions
            {
                AuthenticationScheme = "Cookies",
                AccessDeniedPath = "/Auth/AccessDenied" // access denied path
            });

            // stops claims being remapped to other names
            JwtSecurityTokenHandler.DefaultInboundClaimTypeMap.Clear();

            app.UseOpenIdConnectAuthentication(new OpenIdConnectOptions
            {
                AuthenticationScheme = "oidc",
                Authority = "https://localhost:44344/",
                RequireHttpsMetadata = true,
                ClientId = "CascadesId",
                Scope = { "openid", "profile", "address", "roles", "imagegalleryapi",
                    "subscriptionlevel", "country", "offline_access" }, // scopes this can request
                ResponseType = "code id_token", // receives access token
                SignInScheme = "Cookies", //what persists the user auth,
                SaveTokens = true,
                ClientSecret = "secret",
                GetClaimsFromUserInfoEndpoint = true, // ensures middleware calls enpoint for the info
                Events = new OpenIdConnectEvents()
                {
                    OnTokenValidated = tokenValidatedContext => // When validated
                    {
                        // We can modify the token to only include the claim types we want
                        var identity = tokenValidatedContext.Ticket.Principal.Identity as ClaimsIdentity;

                        var subjectClaim = identity.Claims.FirstOrDefault(x => x.Type == "sub");

                        var newClaimsIdentiry = new ClaimsIdentity(
                            tokenValidatedContext.Ticket.AuthenticationScheme,
                            "given_name",
                            "role");

                        newClaimsIdentiry.AddClaim(subjectClaim);

                        tokenValidatedContext.Ticket = new AuthenticationTicket(
                            new ClaimsPrincipal(newClaimsIdentiry),
                            tokenValidatedContext.Ticket.Properties,
                            tokenValidatedContext.Ticket.AuthenticationScheme);

                        return Task.FromResult(0);
                    },

                    // User Info Endpoint has been called
                    OnUserInformationReceived = userInformationReceivedContext =>
                    {
                        // we can remove items 
                        userInformationReceivedContext.User.Remove("address");

                        return Task.FromResult(0);
                    }
                }

            });
            
            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Gallery}/{action=Index}/{id?}");
            });
        }         
    }
}
