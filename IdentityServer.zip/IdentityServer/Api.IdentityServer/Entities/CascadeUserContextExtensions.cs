﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Marvin.IDP.Entities
{
    public static class CascadeUserContextExtensions
    {
        public static void EnsureSeedDataForContext(this CascadeUserContext context)
        {
            // Add 2 demo users if there aren't any users yet
            if (context.Users.Any())
            {
                return;
            }

            // init users
            var users = new List<User>()
            {
                new User()
                {
                    SubjectId = "d860efca-22d9-47fd-8249-791ba61b07c7",
                    Username = "cascadesupport",
                    Password = "allow",
                    IsActive = true,
                    Claims = {
                         new UserClaim("given_name", "Cascade"),
                         new UserClaim("family_name", "Support"),
                         new UserClaim("address", "533, Some Place"),
                         new UserClaim("role", "admin"),
                         new UserClaim("country", "uk"),
                         new UserClaim("subscriptionlevel", "Admin")
                    }
                },
                new User()
                {
                    SubjectId = "b7539694-97e7-4dfe-84da-b4256e1ff5c7",
                    Username = "Claire",
                    Password = "password",
                    IsActive = true,
                    Claims = {
                         new UserClaim("role", "PayingUser"),
                         new UserClaim("given_name", "Claire"),
                         new UserClaim("family_name", "Underwood"),
                         new UserClaim("address", "Big Street 2"),
                         new UserClaim("subscriptionlevel", "PayingUser"),
                         new UserClaim("country", "be")                    
                }
                }
            };

            context.Users.AddRange(users);
            context.SaveChanges();
        }
    }
}
