﻿using Microsoft.EntityFrameworkCore;

namespace Marvin.IDP.Entities
{
    public class CascadeUserContext : DbContext
    {
        public CascadeUserContext(DbContextOptions<CascadeUserContext> options)
           : base(options)
        {
           
        }

        public DbSet<User> Users { get; set; }
    }
}
