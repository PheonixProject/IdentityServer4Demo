﻿using Marvin.IDP.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Api.IdentityServer
{
    public static class IdentityServerBuilderExtension
    {

        public static IIdentityServerBuilder AddCascadeUserStore(this IIdentityServerBuilder builder)
        {
            builder.Services.AddSingleton<ICascadeUserRepository, CascadeUserRepository>();
            builder.AddProfileService<CascadeProfileService>();

            return builder;
        }
    }
}
