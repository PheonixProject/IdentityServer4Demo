﻿using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Test;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Api.IdentityServer
{
    public static class Config
    {

        public static List<TestUser> GetUsers()
        {
            return new List<TestUser>
            {
                new TestUser
                {
                    SubjectId = Guid.NewGuid().ToString(), //Unique Identifier
                    Username = "cascadesupport",
                    Password = "allow",
                    Claims = new List<Claim> // Info on user (claims are related to scopes)
                    {
                        new Claim("given_name", "Cascade"),
                        new Claim("family_name", "Support"),
                        new Claim("address", "533, Some Place"),
                        new Claim("role", "admin"),
                        new Claim("country", "uk"),
                        new Claim("subscriptionlevel", "Admin")
                    }                    
                },
                new TestUser
                {
                    SubjectId = Guid.NewGuid().ToString(),
                    Username = "aaron",
                    Password = "allow",
                    Claims = new List<Claim>
                    {
                        new Claim("given_name", "Aaron"),
                        new Claim("family_name", "smith"),
                        new Claim("address", "53, Some Place"),
                        new Claim("role", "employee")
                    }
                },
            };
        }

        /// <summary>
        /// Iden Resource map to scopes that give access to iden related claims
        /// Api Resource map to scopes that give access to api resources
        /// </summary>
        /// <returns></returns>
        public static IEnumerable<IdentityResource> GetIdentityResources()
        {
            return new List<IdentityResource>
            {
                new IdentityResources.OpenId(), // required, ensures user id(subjectid) is included
                new IdentityResources.Profile(), // Returns given and family name - profile related claims
                new IdentityResources.Address(),
                new IdentityResource("roles", "Your Role(s)", 
                    new List<string>() { "role" }), // custom identity scope. Name, display name, claims
                new IdentityResource("country", "The country your living in",
                    new List<string>() { "country" }),
                new IdentityResource("subscriptionlevel", "Your subscription level",
                    new List<string>() { "subscriptionlevel" })
            };
        }

        public static IEnumerable<ApiResource> GetApiResources()
        {
            return new List<ApiResource>
            {
                new ApiResource("api1", "My API")
                {
                    Scopes = new List<Scope>()
                    {
                        new Scope()
                        {
                            Name = "api1",
                            UserClaims = new List<string>() { "Email Address" }
                        },
                        new Scope()
                        {
                            Name = "api1.write",
                            UserClaims = new List<string>() { "Email Address" }
                        },
                        new Scope()
                        {
                            Name = "api1.full_access",
                            UserClaims = new List<string>() { "Email Address" }
                        }
                    }
                },
                new ApiResource("imagegalleryapi", "Image Gallery Api",
                new List<string> { "role" })
                {
                    // Required for validation when using ref token
                    ApiSecrets = { new Secret("apisecret".Sha256()) }
                }
            };
        }

        public static IEnumerable<Client> GetClients()
        {
            return new List<Client>
            {
                //new Client
                //{
                //    ClientName = "Cascade",
                //    ClientId = "CascadesId",
                //    AllowedGrantTypes = GrantTypes.Hybrid,
                //    RedirectUris = new List<string>()
                //    {
                //        "http://localhost:1600/signin-oidc"
                //    },
                //    AllowedScopes =
                //    {
                //        IdentityServerConstants.StandardScopes.OpenId,
                //        IdentityServerConstants.StandardScopes.Profile
                //    },
                //    ClientSecrets =
                //    {
                //        new Secret("secret".Sha256())
                //    }
                //    //,AlwaysIncludeUserClaimsInIdToken = true // FOrces the claims to be in the token- not advised!
                //},
                new Client
                {
                    ClientName = "Cascade",
                    ClientId = "CascadesId",
                    AllowedGrantTypes = GrantTypes.HybridAndClientCredentials,
                    
                    // Prevents redirection to consent page on login
                    RequireConsent = false,

                    //Ref token or Self Containted token (JWT)
                    //AccessTokenType = AccessTokenType.Reference,

                    // Default 5 min
                    AuthorizationCodeLifetime = 120,

                    // Sliding means new token being requested updated lifetime
                    // Wont exceeed absolute lifetime.
                    //RefreshTokenExpiration = TokenExpiration.Sliding,

                    // Claims will be updated when token refreshed
                    UpdateAccessTokenClaimsOnRefresh = true,


                    //Allows tokens to be refreshed 
                    AllowOfflineAccess = true,

                    RedirectUris = new List<string>()
                    {
                        "http://localhost:1600/signin-oidc"
                    },
                    AllowedScopes =
                    {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        IdentityServerConstants.StandardScopes.Address,
                        "roles",
                        "imagegalleryapi",
                        "country",
                        "subscriptionlevel"
                    },
                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    }
                    //,AlwaysIncludeUserClaimsInIdToken = true // FOrces the claims to be in the token- not advised!
                },
                new Client
                {
                    ClientId = "client",
                    ClientName = "Client",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPasswordAndClientCredentials,
                    AccessTokenType = AccessTokenType.Reference,

                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    //AllowedScopes = { "api1.read", "api2.write", "api1.write" }
                     AllowedScopes =
                    {
                        "api1.write"
                    }
                },
                new Client
                {
                    ClientId = "ro.client",
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,

                    ClientSecrets =
                    {
                        new Secret("secret".Sha256())
                    },
                    AllowedScopes = { "api1" }
                }
            };
        }

    }
}
