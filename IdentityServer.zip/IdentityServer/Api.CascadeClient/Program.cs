﻿using IdentityModel.Client;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Api.CascadeClient
{
    class Program
    {
        private const string authority = "https://localhost:44344/";
        private const string clientId = "ro.client";
        private const string clientSecret = "secret";
        private const string scope = "api1";
        private const string apiUrl = "https://localhost:44325/api/images";
        private static string ApiToken = "";


        static void Main(string[] args)
        {
            int userInput = 0;
            do
            {
                userInput = DisplayMenu();
                if (userInput == 1)
                {
                    RequestToken();
                }
                if (userInput == 2)
                {
                    AttemptAccess();
                }
                if (userInput == 3)
                {
                    ClearToken();
                }

            } while (userInput != 4);
        }

        static void RequestToken()
        {
            Console.WriteLine("Getting Token");
            ApiToken = GetTokenAsync2().GetAwaiter().GetResult();
            Console.ReadLine();
        }

        static void AttemptAccess()
        {
            Console.WriteLine("Calling API");
            CallApiAsync(ApiToken).GetAwaiter().GetResult();
            Console.ReadLine();
        }

        static void ClearToken()
        {
            ApiToken = string.Empty;
            Console.WriteLine("Cleared Token");
        }

        static public int DisplayMenu()
        {
            Console.Clear();
            while (true)
            {
                Console.WriteLine("");
                Console.WriteLine();
                Console.WriteLine("1. Request Token");
                Console.WriteLine("2. Attempt API access");
                Console.WriteLine("3. Clear Token");
                int result;
                if (Int32.TryParse(Console.ReadLine(), out result))
                    return result;
                else
                    Console.WriteLine("Please enter a number");
            }
        }

        private static async Task MainAsync()
        {
            Console.Title = "Client";
            var token = await GetTokenAsync2();

            Console.WriteLine();

            await CallApiAsync(token);

        }

        private static async Task<string> GetTokenAsync2()
        {
            var discos = new DiscoveryClient(authority);
            var disco = await discos.GetAsync();

            if (disco.IsError)
            {
                Console.WriteLine(disco.Error);
                return null;
            }

            var tokenClient = new TokenClient(disco.TokenEndpoint, "ro.client", "secret");

            var tokenResponse = await tokenClient.RequestResourceOwnerPasswordAsync("aaron", "allow", "api1");

            if (tokenResponse.IsError)
            {
                Console.WriteLine(tokenResponse.Error);
            }

            Console.WriteLine(tokenResponse.Json);
            Console.WriteLine("\n\n");

            return string.Empty;
        }

        private static async Task<string> GetTokenAsync()
        {
            var disco = new DiscoveryClient(authority);
            var discoResponse = await disco.GetAsync();

            if (discoResponse.IsError)
            {
                Console.WriteLine(discoResponse.Error);
                return null;
            }

            var tokenClient = new TokenClient(discoResponse.TokenEndpoint, clientId, clientSecret);
            //var tokenResponse = await tokenClient.RequestClientCredentialsAsync(scope);

            var moo = await tokenClient.RequestResourceOwnerPasswordAsync("cascadesupport", "allow", "api1.write");

            //if (tokenResponse.IsError)
            //{
            //    Console.WriteLine(tokenResponse.Error);
            //    return null;
            //}

            //Console.WriteLine(tokenResponse.Json);

            return string.Empty;
        }

        public static async Task CallApiAsync(string token)
        {
            var client = new HttpClient();
            client.SetBearerToken(token);

            var response = await client.GetAsync(apiUrl);
            if (!response.IsSuccessStatusCode)
            {
                Console.WriteLine(response.StatusCode);
            }
            else
            {
                var content = await response.Content.ReadAsStringAsync();
                Console.WriteLine(JArray.Parse(content));
            }
        }
    }
}
